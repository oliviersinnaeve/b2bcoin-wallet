package com.b2beyond.wallet.b2bcoin.view.view.panel;

import com.b2beyond.wallet.b2bcoin.util.B2BUtil;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.SoftBevelBorder;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

public class DonationPanel extends JPanel {

    /**
     * Create the panel.
     */
    public DonationPanel() {
        setBackground(B2BUtil.mainColor);
        setToolTipText("This panel gives you some wallet you can donate to. The is purely made on private funds.");
        setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
        Border border = getBorder();
        Border margin = new EmptyBorder(10,10,10,10);
        setBorder(new CompoundBorder(border, margin));

        GridBagLayout gridBagLayout = new GridBagLayout();
        gridBagLayout.columnWidths = new int[]{1, 1, 1};
        gridBagLayout.rowHeights = new int[]{1, 1, 1, 1, 1};
        gridBagLayout.columnWeights = new double[]{0.02, 0.96, 0.02};
        gridBagLayout.rowWeights = new double[]{0.02, 0.48, 0.02, 0.48, 0.02};
        setLayout(gridBagLayout);

        JTextField btcDonationAddressLabel =new JTextField("Donation - BTC Address : 1E8eqLxrR9GtkZBNW2hwL6MjLBhCiZdoqS");
        btcDonationAddressLabel.setEditable(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.gridx = 1;
        gbc.gridy = 1;
        add(btcDonationAddressLabel, gbc);

        JLabel litecoinDonationAddressLabel = new JLabel("Donation - LTC Address : LTxYayXRs9Cm6rjfJKFh862GF7DgXecgx8");
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.gridx = 1;
        gbc.gridy = 3;
        add(litecoinDonationAddressLabel, gbc);
    }

}
