package com.b2beyond.wallet.b2bcoin.daemon;


public interface Daemon {

    void stop();

}
