package com.b2beyond.wallet.b2bcoin.daemon.rpc.model;


public class Payment {

    private String transactionHash;


    public String getTransactionHash() {
        return transactionHash;
    }

    public void setTransactionHash(String transactionHash) {
        this.transactionHash = transactionHash;
    }

}
