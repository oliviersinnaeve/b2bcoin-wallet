package com.b2beyond.wallet.b2bcoin.daemon.rpc.model;

/**
 * Created by oliviersinnaeve on 13/09/17.
 */
public class ViewSecretKey {

    private String viewSecretKey;


    public String getViewSecretKey() {
        return viewSecretKey;
    }

    public void setViewSecretKey(String viewSecretKey) {
        this.viewSecretKey = viewSecretKey;
    }
}
