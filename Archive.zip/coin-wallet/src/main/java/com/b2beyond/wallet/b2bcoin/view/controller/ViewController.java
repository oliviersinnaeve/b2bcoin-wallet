package com.b2beyond.wallet.b2bcoin.view.controller;

import javax.swing.JComponent;

public interface ViewController<T, C extends JComponent> {

}
